import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

	public class SampleMYSQLConnection
	{
	  String username="";
	  String password="";
	  int customerID=0;
	  String customerName="";
	  String customerSurname="";
	  String phoneNumber="";
	  String creditCardNumber="";
	  
	  Connection conn;
	  Scanner scanner;
	  Statement statement;

	  public static void main(String[] args) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	  {
		  new SampleMYSQLConnection();
	  }
	 
	  public SampleMYSQLConnection()throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	  {
	      Class.forName("com.mysql.jdbc.Driver").newInstance();
	      String url = "jdbc:mysql://localhost/Customer";
	      
	      conn = DriverManager.getConnection(url, "root", "12345");
	      conn.setAutoCommit(false);
	      
	      scanner = new Scanner(System.in);
	      String t_username="", t_password="";
	      
	      System.out.println("Welcome to the user panel");
	      System.out.println("Please login to the system in order to view your records.");
	      
	      System.out.print("Username: ");
	      t_username = scanner.nextLine();
	      System.out.print("Password: ");
	      t_password = scanner.nextLine();
	      
	      String selectTableSQL = "SELECT * from UserTable WHERE Username='"+t_username+"' AND Password='"+t_password+"'";
	      statement = conn.createStatement();
	      ResultSet rs = statement.executeQuery(selectTableSQL);
	      if(rs.next()){
	    	  username = t_username;
	    	  password = t_password;
	    	  System.out.println("Logged in successfully!");
	    	  doCustomerMenu();
	      }
	      else{
	    	  System.out.println("Login attempt was not successful!");
	    	  return;
	    			  
	      }
	     
	      System.out.println("Program exits!");
	      statement.close();
	      conn.close();
	    
	  }
	  
	  private void doCustomerMenu()  throws SQLException {
		  		
			String selectTableSQL = "SELECT * from CustomerTable WHERE Username='"+username+"'";
		    statement = conn.createStatement();
			ResultSet rs = statement.executeQuery(selectTableSQL);
			while (rs.next()) {
		    	  customerName = rs.getString("FirstName");
		    	  customerSurname = rs.getString("LastName");	
		    	  customerID = rs.getInt("CustomerID");
		    }
			
			System.out.println("Welcome "+customerName+" "+customerSurname);
			while(true){
				
				System.out.println("MAIN MENU --- Enter ");
				System.out.println("1 to view your orders");
				System.out.println("2 to update your information");
				System.out.println("9 to exit");
				
				int choice = scanner.nextInt();
				scanner.nextLine();
				if(choice==9)
					return;
				else if(choice == 1){
					
					displayOrders();
				}
				else if(choice == 2){
					updateUserInformation();
				}
				else {
					
					System.out.println("you entered an invalid choice! Please enter a valid one!");
				}
				
				
			}
	  }	
	  
	  
	  private void updateUserInformation() throws SQLException {
		  String selectUserInfo = "SELECT * from CustomerTable WHERE Username='"+username+"'";
		  statement = conn.createStatement();
		  ResultSet rs = statement.executeQuery(selectUserInfo);
		  while (rs.next()) {
			  customerName = rs.getString("FirstName");
			  customerSurname = rs.getString("LastName");	
			  customerID = rs.getInt("CustomerID");
			  phoneNumber = rs.getString("Phone");
			  creditCardNumber = rs.getString("CreditCardNumber");
		  }
		  System.out.println("Your current information: ");
		  System.out.println("Phone Number: " + phoneNumber);
		  System.out.println("Credit Card Number: " + creditCardNumber);
		  
		  System.out.println("Note that you can only update your phone and credit card information");
		  String t_phone="", t_creditcard="";
		  System.out.print("New phone number: ");
		  t_phone = scanner.nextLine();
		  System.out.print("New credit card number (in aaaa-bbbb-cccc-dddd format):");
		  t_creditcard = scanner.nextLine();
		  
		  System.out.println("Username"+username);
		  String selectTableSQL1 = "UPDATE CustomerTable SET Phone='"+t_phone+"' WHERE Username='"+username+"'";
		  String selectTableSQL2 = "UPDATE CustomerTable SET CreditCardNumber='"+t_creditcard+"' WHERE Username='"+username+"'";
		  
		 
		  statement.executeUpdate(selectTableSQL1);
		  statement.executeUpdate(selectTableSQL2);
		  
		  conn.commit();
	}

	  private void displayOrders() throws SQLException {
		  
		  System.out.println("ORDER MENU --- Enter ");
		  System.out.println("1 to see all of your orders");
		  System.out.println("2 to see the details of a specific order");
		  int selection = scanner.nextInt();
		  scanner.nextLine();
		  if( selection == 1){
			  displayAllOrders();
		  }
		  else if( selection==2){
			  System.out.print("Enter the order ID: ");
			  String t_orderID = scanner.nextLine();
			
			  String selectTableSQL = "SELECT OrderTable.OrderID, OrderTable.Date, OrderTable.Quantity, ProductTable.ProductName, "
					  +"ProductTable.UnitPrice, CustomerTable.FirstName, CustomerTable.LastName from OrderTable INNER "
					  +"JOIN CustomerTable on CustomerTable.CustomerID=OrderTable.CustomerID INNER JOIN ProductTable on "
					  +"OrderTable.ProductID=ProductTable.ProductID and OrderTable.OrderID='"+t_orderID+"' and OrderTable.CustomerID="+customerID;
			  
			  
			  statement = conn.createStatement();
			  ResultSet rs = statement.executeQuery(selectTableSQL);
			  while (rs.next()) {
					  
			   	  System.out.println(
			   	      "Customer Name:"+rs.getString("CustomerTable.FirstName")+
			   	      " "+rs.getString("CustomerTable.LastName")+
			   		  " Order ID: "+rs.getInt("OrderID")+ 
					  " Date: "+rs.getDate("OrderTable.Date").toString()+
			   		  " Quantity: "+rs.getInt("OrderTable.Quantity")+
			   		  " Product: "+rs.getString("ProductTable.ProductName")+
			   		  " Unit Price: "+rs.getFloat("ProductTable.UnitPrice"));
			   	  	  }
			  System.out.println();
			  return;
		  }
		  else {
			  System.out.println("Invalid selection!");
			  return;
		  }
		  
		  
	  }
	  
	  private void displayAllOrders() throws SQLException{
		  String selectTableSQL = "SELECT OrderTable.OrderID, OrderTable.Date, OrderTable.Quantity, ProductTable.ProductName, "
				  +"ProductTable.UnitPrice, CustomerTable.FirstName, CustomerTable.LastName from OrderTable INNER "
				  +"JOIN CustomerTable on CustomerTable.CustomerID=OrderTable.CustomerID INNER JOIN ProductTable on "
				  +"OrderTable.ProductID=ProductTable.ProductID and OrderTable.CustomerID="+customerID;
		  
		  statement = conn.createStatement();
		  ResultSet rs = statement.executeQuery(selectTableSQL);
		  while (rs.next()) {
				  
		   	  System.out.println( "Order ID: "+rs.getString("OrderTable.OrderID")+
		   		  "   Customer Name:"+rs.getString("CustomerTable.FirstName")+
			   	  " "+rs.getString("CustomerTable.LastName")+
				  " Date: "+rs.getDate("OrderTable.Date").toString()+
		   		  " Quantity: "+rs.getInt("OrderTable.Quantity")+
		   		  " Product: "+rs.getString("ProductTable.ProductName")+
		   		  " Unit Price: "+rs.getFloat("ProductTable.UnitPrice"));
		   	  	  }
		  System.out.println();
	  
	  }
	 
	}
