#!/usr/bin/python
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
from os import curdir, sep

PORT_NUMBER = 8100

class myHandler(BaseHTTPRequestHandler):
	
	#Handler for the GET requests
	def do_GET(self):
		print "HEADER ------------------"
		print self.headers
		print "-------------------------"
		print "PATH --------------------"
		print self.path
		print "-------------------------"
		if self.path == "/sdattacker":
			self.path = "/sdattacker.html"
		try:
			f = open(curdir + sep + self.path) 

			self.send_response(200)
			self.send_header('Content-type',"text/html; charset=iso-8859-1")
			
			self.end_headers()
			self.wfile.write(f.read())
			
			f.close()
			return

		except IOError:
			self.send_error(404,'File Not Found: %s' % self.path)

try:
	server = HTTPServer(('', PORT_NUMBER), myHandler)
	print 'Started httpserver on port ' , PORT_NUMBER

	server.serve_forever()

except KeyboardInterrupt:
	server.socket.close()
