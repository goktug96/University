#!/usr/bin/python
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
from os import curdir, sep
import Cookie
import datetime
import ssl

PORT_NUMBER = 4443

class myHandler(BaseHTTPRequestHandler):
	
	#Handler for the GET requests
	def do_GET(self):
		parsed_path = self.path.split('?',1)
		if len(parsed_path) > 1:
			cookie_array = parsed_path[1].split('&',1)
			first_cookie = cookie_array[0].split('=',1)
			second_cookie = cookie_array[1].split('=',1)
		if parsed_path[0] == "/app":
			self.path="/mainssl.html"

		try:
			f = open(curdir + sep + self.path) 
			self.send_response(200)
			self.send_header('Content-type',"text/html; charset=iso-8859-1")
			if len(parsed_path) > 1:
				cookie_first = Cookie.SimpleCookie()	#first cookie
				cookie_first[first_cookie[0]] = first_cookie[1]

				cookie_second = Cookie.SimpleCookie()	#second cookie
				cookie_second[second_cookie[0]] = second_cookie[1]

				expires = datetime.datetime(2099, 2, 14, 18, 30, 14) + datetime.timedelta(hours=1)
				cookie_second[second_cookie[0]]['expires'] = expires.strftime('%a, %d %b %Y %H:%M:%S') # Wdy, DD-Mon-YY HH:MM:SS GMT

				self.send_header("Set-Cookie", cookie_first.output(header='', sep=';'))
				self.send_header("Set-Cookie", cookie_second.output(header='', sep=';'))
			self.end_headers()
			self.wfile.write(f.read())
			f.close()
			return

		except IOError:
			self.send_error(404,'File Not Found: %s' % self.path)

try:
	server = HTTPServer(('', PORT_NUMBER), myHandler)
	server.socket = ssl.wrap_socket (server.socket, server_side=True, certfile='yourpemfile.pem')	
	print 'Started httpserver on port ' , PORT_NUMBER

	server.serve_forever()

except KeyboardInterrupt:
	server.socket.close()
